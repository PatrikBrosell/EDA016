/**
 * Labyrint (Maze).
 */

package se.lth.cs.ptdc.maze;
