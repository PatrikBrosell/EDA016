/**
 * Ritfönster (SimpleWindow).
 */

package se.lth.cs.ptdc.window;

