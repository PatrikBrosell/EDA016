/**
 * Geometriska figurer och lista av figurer (Shape och ShapeList).
 */

package se.lth.cs.ptdc.shapes;

