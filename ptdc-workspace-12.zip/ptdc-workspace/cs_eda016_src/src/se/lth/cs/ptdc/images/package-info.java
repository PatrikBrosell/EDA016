/**
 * Bildbehandling (ImageFilter och ImageGUI).
 */

package se.lth.cs.ptdc.images;

