/**
 * Fraktaler (MandelbrotGUI).
 */

package se.lth.cs.ptdc.fractal;

