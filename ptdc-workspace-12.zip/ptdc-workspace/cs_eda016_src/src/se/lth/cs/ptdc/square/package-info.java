/**
 * Kvadrater (Square).
 */

package se.lth.cs.ptdc.square;

