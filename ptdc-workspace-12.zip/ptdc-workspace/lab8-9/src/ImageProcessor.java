import se.lth.cs.ptdc.images.ImageFilter;
import se.lth.cs.ptdc.images.ImageGUI;

public class ImageProcessor {
	public static void main(String[] args) {
		ImageFilter[] filters = new ImageFilter[1];
		filters[0] = new IdentityFilter("Identity Filter");
		new ImageGUI(filters);
	}
}
